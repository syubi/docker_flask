# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 10:16:02 2022

@author: syubi
"""

from flask import Flask,request

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import sessionmaker


import psycopg2


	
app = Flask(__name__)

 

class Config(object):

    """配置引數"""

    # 設定連線資料庫的URL

    user = 'postgres'
    # database="table1", user="postgres", password="00000000", host="127.0.0.1", port="5432")

    password = '00000000'

    database = 'table1'

    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://%s:%s@127.0.0.1:5432/%s' % (user,password,database)

 

    # 設定sqlalchemy自動更跟蹤資料庫

    SQLALCHEMY_TRACK_MODIFICATIONS = True

 

    # 查詢時會顯示原始SQL語句

    app.config['SQLALCHEMY_ECHO'] = True

 

    # 禁止自動提交資料處理

    app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = False

 

# 讀取配置

app.config.from_object(Config)

 

# 建立資料庫sqlalchemy工具物件

db = SQLAlchemy(app)



@app.route('/',methods=['POST','GET'])
def hello():
    return "Hello World!"




@app.route("/submit")
def submit():
    aa=request.args.get('custmer_id')
    bb=request.args.get('order_id')
    cc=request.args.get('customer_name')
    dd=request.args.get('puechase_time')
    
    order1 = Order1()
    
    order1.customer_name=cc
    order1.custmer_id=aa
    order1.order_id=bb
    order1.puechase_time=dd
    
    db.session.add(order1)
    db.session.commit()
    return"success"
    
@app.route("/submit1")
def submit1():
    aa1=request.args.get('oldcustmer_id')
    bb1=request.args.get('oldorder_id')
    cc1=request.args.get('oldcustomer_name')
    dd1=request.args.get('oldpuechase_time')
    
    
    aa2=request.args.get('newcustmer_id')
    bb2=request.args.get('neworder_id')
    cc2=request.args.get('newcustomer_name')
    dd2=request.args.get('newpuechase_time')
    
    order1 = Order1()
    

    order1 = Order1.query.filter(Order1.custmer_id == aa1 or Order1.order_id == bb1 or Order1.customer_name == cc1 or Order1.puechase_time == dd1).first()

    
    order1.customer_name=cc2
    order1.custmer_id=aa2
    order1.order_id=bb2
    order1.puechase_time=dd2

    db.session.add(order1)
    db.session.commit()

    # # 已存在判斷 擋下
    # return "oldcustmer_id= "+aa1+"  newcustmer_id="+aa2
    
    return"success"
    

@app.route('/order/add')
def add1():
   
    return"""  
<div class="jumbotron jumbotron-fluid">
  <div class="container">

   
    <form action="/submit" method="GET">
    <div class="form-group">
        <label for="fname">custmer_id:</label>
        <input type="text" name="custmer_id" class="form-control" placeholder="請輸入custmer_id" ><br>
        <label for="fname">order_id:</label>
        <input type="text" name="order_id" class="form-control" placeholder="請輸入order_id" ><br>
        <label for="fname">customer_name:</label>
        <input type="text" name="customer_name" class="form-control" placeholder="請輸入customer_name" ><br>
        <label for="fname">puechase_time:</label>
        <input type="text" name="puechase_time" class="form-control" placeholder="請輸入puechase_time" ><br>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">確認送出</button>
    </div>
</form>
  </div>
</div>
 """

@app.route('/order/modify')
def modify1(): 
    
    return"""  
<div class="jumbotron jumbotron-fluid">
  <div class="container">

   
    <form action="/submit1" method="GET">
    <div class="form-group">
            <label for="fname">custmer_id:</label>
            <input type="text" name="oldcustmer_id" class="form-control" placeholder="請輸入舊custmer_id" ><br>
            <label for="fname">order_id:</label>
            <input type="text" name="oldorder_id" class="form-control" placeholder="請輸入舊order_id" ><br>
            <label for="fname">customer_name:</label>
            <input type="text" name="oldcustomer_name" class="form-control" placeholder="請輸入舊customer_name" ><br>
            <label for="fname">puechase_time:</label>
            <input type="text" name="oldpuechase_time" class="form-control" placeholder="請輸入舊puechase_time" ><br>
            <label for="fname">custmer_id:</label>
            <input type="text" name="newcustmer_id" class="form-control" placeholder="請輸入新custmer_id" ><br>
            <label for="fname">order_id:</label>
            <input type="text" name="neworder_id" class="form-control" placeholder="請輸入新order_id" ><br>
            <label for="fname">customer_name:</label>
            <input type="text" name="newcustomer_name" class="form-control" placeholder="請輸入新customer_name" ><br>
            <label for="fname">puechase_time:</label>
            <input type="text" name="newpuechase_time" class="form-control" placeholder="請輸入新puechase_time" ><br>
        
        
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">確認送出</button>
    </div>
</form>
  </div>
</div>
 """


class Order1(db.Model):

    # 定義表名

    __tablename__ = 'order'

    # 定義欄位

    id = db.Column(db.Integer, primary_key=True,autoincrement=True)

    custmer_id = db.Column(db.String(64), unique=True)

    order_id = db.Column(db.String(64), unique=True) 
    
    customer_name = db.Column(db.String(64), unique=True)
    
    puechase_time = db.Column(db.String(64), unique=True)
    
class Order_Item(db.Model):

    # 定義表名

    __tablename__ = 'order_item'

    # 定義欄位

    id = db.Column(db.Integer, primary_key=True,autoincrement=True)

    order_id = db.Column(db.String(64), unique=True) 

    product_name = db.Column(db.String(64), unique=True) 

    amount=db.Column(db.String(64), unique=True) 
    
    product_id=db.Column(db.String(64), unique=True) 
    
    price=db.Column(db.String(64), unique=True) 
    


if __name__ == '__main__':
    app.run(port=8088,debug=True)

 